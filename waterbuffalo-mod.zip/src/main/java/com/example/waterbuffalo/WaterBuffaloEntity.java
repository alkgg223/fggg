package com.example.waterbuffalo;

import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathType;

public class WaterBuffaloEntity extends Animal {
    private static final EntityDataAccessor<Boolean> SITTING =
            SynchedEntityData.defineId(WaterBuffaloEntity.class, EntityDataSerializers.BOOLEAN);

    /** أطعمة التزاوج والاستدراج */
    private static final Ingredient BREED_FOOD =
            Ingredient.of(Items.WHEAT, Items.CARROT, Items.POTATO, Items.BEETROOT);

    private float sitAmount, sitAmountO;
    private int eatAnimationTick;

    public WaterBuffaloEntity(EntityType<? extends WaterBuffaloEntity> type, Level level) {
        super(type, level);
        // يمشي داخل الماء الضحل بدون تجنّبه
        this.setPathfindingMalus(PathType.WATER, 0.0F);
        this.setPathfindingMalus(PathType.WATER_BORDER, 0.0F);
    }

    /** دم = 80 (4 أضعاف اللاعب) ، ضرر 12 => ضربتان تقتلان لاعباً بدون درع على الصعوبة العادية */
    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 80.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.2D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.3D, true));
        this.goalSelector.addGoal(2, new BreedGoal(this, 1.0D));
        this.goalSelector.addGoal(3, new TemptGoal(this, 1.1D, BREED_FOOD, false));
        this.goalSelector.addGoal(4, new FollowParentGoal(this, 1.1D));
        this.goalSelector.addGoal(5, new BuffaloGoals.EatCropGoal(this));
        this.goalSelector.addGoal(5, new BuffaloGoals.EatItemGoal(this));
        this.goalSelector.addGoal(6, new BuffaloGoals.GoToWaterGoal(this));
        this.goalSelector.addGoal(7, new BuffaloGoals.SitDownGoal(this));
        this.goalSelector.addGoal(8, new RandomStrollGoal(this, 0.8D) {
            @Override
            public boolean canUse() {
                // يميل للبقاء في الماء
                if (this.mob.isInWater() && this.mob.getRandom().nextInt(3) != 0) return false;
                return super.canUse();
            }
        });
        this.goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(10, new RandomLookAroundGoal(this));

        // عدائي فقط عندما يتعرض للضرب (ويستنفر القطيع)
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this).setAlertOthers());
    }

    // ---------- الطعام ----------
    /** كل ما يأكله الجاموس (القمح بكل أشكاله + الجزر والبطاطس والشمندر) */
    public static boolean isEdible(ItemStack s) {
        return s.is(Items.WHEAT) || s.is(Items.WHEAT_SEEDS) || s.is(Items.HAY_BLOCK) || s.is(Items.BREAD)
                || s.is(Items.CARROT) || s.is(Items.POTATO) || s.is(Items.BEETROOT) || s.is(Items.BEETROOT_SEEDS);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return BREED_FOOD.test(stack);
    }

    public void eatFood(float heal) {
        this.heal(heal);
        this.playSound(SoundEvents.GENERIC_EAT, 1.0F, 1.0F);
        if (this.isBaby()) {
            this.ageUp(AgeableMob.getSpeedUpSecondsWhenFeeding(-this.getAge()));
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isFood(stack) && isEdible(stack)) { // الخبز والبذور والتبن (غير مخصصة للتزاوج)
            if (!level().isClientSide) {
                eatFood(4.0F);
                startEatingAnimation();
                if (!player.getAbilities().instabuild) stack.shrink(1);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ---------- الجلوس ----------
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SITTING, false);
    }

    public boolean isSitting() { return this.entityData.get(SITTING); }
    public void setSitting(boolean v) { this.entityData.set(SITTING, v); }

    public float getSitAmount(float pt) { return Mth.lerp(pt, sitAmountO, sitAmount); }

    @Override
    public void tick() {
        super.tick();
        sitAmountO = sitAmount;
        float target = isSitting() ? 1.0F : 0.0F;
        sitAmount += Mth.clamp(target - sitAmount, -0.08F, 0.08F);
    }

    // ---------- أنيميشن الأكل ----------
    public void startEatingAnimation() {
        this.eatAnimationTick = 40;
        this.level().broadcastEntityEvent(this, (byte) 10);
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == 10) this.eatAnimationTick = 40;
        else super.handleEntityEvent(id);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (eatAnimationTick > 0) eatAnimationTick--;
    }

    public float getEatAnimationScale(float pt) {
        if (eatAnimationTick <= 0) return 0.0F;
        float t = eatAnimationTick - pt;
        return Mth.clamp(Math.min(t, 40.0F - t) / 4.0F, 0.0F, 1.0F);
    }

    // ---------- القتال ----------
    @Override
    public boolean canAttack(LivingEntity target) {
        return !this.isBaby() && super.canAttack(target); // الصغير لا يهاجم
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && !level().isClientSide && isSitting()) setSitting(false);
        return result;
    }

    // لا يطفو إلا في الماء العميق (يمشي ويجلس في الماء الضحل)
    public double getFluidJumpThreshold() {
        return 1.0D;
    }

    @Override
    public WaterBuffaloEntity getBreedOffspring(ServerLevel level, AgeableMob other) {
        return WaterBuffaloMod.WATER_BUFFALO.get().create(level);
    }

    // ---------- الأصوات ----------
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.COW_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.COW_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.COW_DEATH; }
    @Override protected void playStepSound(BlockPos pos, BlockState state) { this.playSound(SoundEvents.COW_STEP, 0.15F, 1.0F); }
    @Override protected float getSoundVolume() { return 0.8F; }
}
