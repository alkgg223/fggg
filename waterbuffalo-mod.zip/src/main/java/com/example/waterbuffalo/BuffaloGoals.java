package com.example.waterbuffalo;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;

public class BuffaloGoals {

    /** يجلس/يرقد لفترة (أكثر احتمالاً داخل الماء) */
    public static class SitDownGoal extends Goal {
        private final WaterBuffaloEntity buf;
        private int sitTicks;

        public SitDownGoal(WaterBuffaloEntity buf) {
            this.buf = buf;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            if (buf.getTarget() != null || buf.isInLove() || buf.isSitting()) return false;
            if (!buf.onGround()) return false;
            if (buf.getFluidHeight(FluidTags.WATER) >= 1.0D) return false;
            return buf.getRandom().nextInt(buf.isInWater() ? 250 : 600) == 0;
        }

        @Override
        public void start() {
            buf.getNavigation().stop();
            buf.setSitting(true);
            sitTicks = (buf.isInWater() ? 400 : 200) + buf.getRandom().nextInt(400);
        }

        @Override
        public boolean canContinueToUse() {
            return buf.isSitting() && sitTicks > 0 && buf.getTarget() == null && !buf.isInLove();
        }

        @Override
        public void tick() {
            sitTicks--;
            buf.getNavigation().stop();
        }

        @Override
        public void stop() {
            buf.setSitting(false);
        }
    }

    /** يأكل المحاصيل الناضجة (قمح، جزر، بطاطس، شمندر) ثم تعود شتلة صغيرة */
    public static class EatCropGoal extends Goal {
        private static final int RADIUS = 8;
        private final WaterBuffaloEntity buf;
        private BlockPos target;
        private int eatTicks, giveUp, cooldown;

        public EatCropGoal(WaterBuffaloEntity buf) {
            this.buf = buf;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        static boolean eatable(BlockState s) {
            return (s.is(Blocks.WHEAT) || s.is(Blocks.CARROTS) || s.is(Blocks.POTATOES) || s.is(Blocks.BEETROOTS))
                    && s.getBlock() instanceof CropBlock crop && crop.isMaxAge(s);
        }

        @Override
        public boolean canUse() {
            if (cooldown > 0) { cooldown--; return false; }
            if (buf.getTarget() != null || buf.isSitting()) return false;
            if (buf.getRandom().nextInt(20) != 0) return false;
            if (!buf.level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return false;
            target = find();
            return target != null;
        }

        private BlockPos find() {
            BlockPos o = buf.blockPosition();
            BlockPos best = null;
            double bd = Double.MAX_VALUE;
            for (BlockPos p : BlockPos.betweenClosed(o.offset(-RADIUS, -2, -RADIUS), o.offset(RADIUS, 2, RADIUS))) {
                if (eatable(buf.level().getBlockState(p))) {
                    double d = p.distSqr(o);
                    if (d < bd) { bd = d; best = p.immutable(); }
                }
            }
            return best;
        }

        @Override
        public void start() {
            eatTicks = 0;
            giveUp = 300;
            buf.getNavigation().moveTo(target.getX() + 0.5, target.getY(), target.getZ() + 0.5, 1.0D);
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && giveUp > 0 && buf.getTarget() == null
                    && eatable(buf.level().getBlockState(target));
        }

        @Override
        public void tick() {
            giveUp--;
            double cx = target.getX() + 0.5, cy = target.getY() + 0.3, cz = target.getZ() + 0.5;
            buf.getLookControl().setLookAt(cx, cy, cz);
            if (buf.distanceToSqr(cx, buf.getY(), cz) > 6.25D) {
                if (buf.getNavigation().isDone()) buf.getNavigation().moveTo(cx, target.getY(), cz, 1.0D);
                return;
            }
            buf.getNavigation().stop();
            if (eatTicks == 0) buf.startEatingAnimation();
            if (++eatTicks >= 40) {
                Level level = buf.level();
                BlockState st = level.getBlockState(target);
                if (eatable(st)) {
                    level.levelEvent(2001, target, Block.getId(st));
                    level.setBlock(target, ((CropBlock) st.getBlock()).getStateForAge(0), 2);
                    buf.eatFood(4.0F);
                }
                cooldown = 400;
                target = null;
            }
        }

        @Override
        public void stop() {
            target = null;
            buf.getNavigation().stop();
        }
    }

    /** يأكل الطعام الملقى على الأرض (قمح، بذور، خبز، تبن، جزر، بطاطس...) */
    public static class EatItemGoal extends Goal {
        private final WaterBuffaloEntity buf;
        private ItemEntity item;
        private int eatTicks, cooldown;

        public EatItemGoal(WaterBuffaloEntity buf) {
            this.buf = buf;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (cooldown > 0) { cooldown--; return false; }
            if (buf.getTarget() != null || buf.isSitting() || buf.getRandom().nextInt(10) != 0) return false;
            List<ItemEntity> list = buf.level().getEntitiesOfClass(ItemEntity.class,
                    buf.getBoundingBox().inflate(10.0D, 4.0D, 10.0D),
                    e -> e.isAlive() && WaterBuffaloEntity.isEdible(e.getItem()));
            item = list.stream().min(Comparator.comparingDouble(buf::distanceToSqr)).orElse(null);
            return item != null;
        }

        @Override
        public void start() {
            eatTicks = 0;
            buf.getNavigation().moveTo(item, 1.0D);
        }

        @Override
        public boolean canContinueToUse() {
            return item != null && item.isAlive() && buf.getTarget() == null;
        }

        @Override
        public void tick() {
            buf.getLookControl().setLookAt(item);
            if (buf.distanceToSqr(item) > 6.25D) {
                if (buf.getNavigation().isDone()) buf.getNavigation().moveTo(item, 1.0D);
                return;
            }
            buf.getNavigation().stop();
            if (eatTicks == 0) buf.startEatingAnimation();
            if (++eatTicks >= 25) {
                ItemStack stack = item.getItem();
                stack.shrink(1);
                if (stack.isEmpty()) item.discard(); else item.setItem(stack);
                buf.eatFood(4.0F);
                cooldown = 40;
                item = null;
            }
        }

        @Override
        public void stop() {
            item = null;
            buf.getNavigation().stop();
        }
    }

    /** يبحث عن ماء ضحل قريب ويتجه إليه */
    public static class GoToWaterGoal extends Goal {
        private final WaterBuffaloEntity buf;
        private BlockPos target;

        public GoToWaterGoal(WaterBuffaloEntity buf) {
            this.buf = buf;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (buf.isInWater() || buf.isSitting() || buf.getTarget() != null) return false;
            if (buf.getRandom().nextInt(80) != 0) return false;
            Level l = buf.level();
            for (int i = 0; i < 40; i++) {
                BlockPos p = buf.blockPosition().offset(
                        buf.getRandom().nextInt(29) - 14, buf.getRandom().nextInt(9) - 4, buf.getRandom().nextInt(29) - 14);
                if (l.getFluidState(p).is(FluidTags.WATER)
                        && l.getFluidState(p.above()).isEmpty()
                        && !l.getFluidState(p.below()).is(FluidTags.WATER)) {
                    target = p;
                    return true;
                }
            }
            return false;
        }

        @Override
        public void start() {
            buf.getNavigation().moveTo(target.getX() + 0.5, target.getY(), target.getZ() + 0.5, 1.0D);
        }

        @Override
        public boolean canContinueToUse() {
            return !buf.getNavigation().isDone() && !buf.isInWater() && buf.getTarget() == null;
        }
    }
}
