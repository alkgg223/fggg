package com.example.waterbuffalo;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(WaterBuffaloMod.MODID)
public class WaterBuffaloMod {
    public static final String MODID = "waterbuffalo";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<WaterBuffaloEntity>> WATER_BUFFALO =
            ENTITIES.register("water_buffalo", () ->
                    EntityType.Builder.of(WaterBuffaloEntity::new, MobCategory.CREATURE)
                            .sized(1.6F, 1.6F)
                            .eyeHeight(1.3F)
                            .clientTrackingRange(10)
                            .build("water_buffalo"));

    public static final DeferredItem<DeferredSpawnEggItem> WATER_BUFFALO_SPAWN_EGG =
            ITEMS.register("water_buffalo_spawn_egg", () ->
                    new DeferredSpawnEggItem(WATER_BUFFALO, 0x3C3C40, 0x8F7A55, new Item.Properties()));

    public WaterBuffaloMod(IEventBus modBus) {
        ENTITIES.register(modBus);
        ITEMS.register(modBus);
        modBus.addListener(this::onAttributes);
        modBus.addListener(this::onSpawnPlacements);
        modBus.addListener(this::onCreativeTab);
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(WATER_BUFFALO.get(), WaterBuffaloEntity.createAttributes().build());
    }

    private void onSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(WATER_BUFFALO.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::checkAnimalSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    private void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(WATER_BUFFALO_SPAWN_EGG.get());
        }
    }
}
