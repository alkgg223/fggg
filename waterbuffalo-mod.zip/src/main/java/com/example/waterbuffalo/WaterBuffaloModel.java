package com.example.waterbuffalo;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * نموذج الجاموس. يمكنك استبدال createBodyLayer بالكود الذي يصدّره Blockbench
 * (Export > Modded Entity) مع الحفاظ على أسماء الأجزاء: body, head, tail, leg_fl, leg_fr, leg_bl, leg_br
 */
public class WaterBuffaloModel extends EntityModel<WaterBuffaloEntity> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(WaterBuffaloMod.MODID, "water_buffalo"), "main");

    private final ModelPart root, body, head, tail, legFL, legFR, legBL, legBR;

    public WaterBuffaloModel(ModelPart root) {
        super(RenderType::entityCutoutNoCull);
        this.root = root;
        this.body = root.getChild("body");
        this.head = body.getChild("head");
        this.tail = body.getChild("tail");
        this.legFL = root.getChild("leg_fl");
        this.legFR = root.getChild("leg_fr");
        this.legBL = root.getChild("leg_bl");
        this.legBR = root.getChild("leg_br");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 40).addBox(-8F, -6F, -13F, 16F, 12F, 26F),
                PartPose.offset(0F, 9F, 0F));

        // سنام الكتف
        body.addOrReplaceChild("hump",
                CubeListBuilder.create().texOffs(0, 84).addBox(-6F, -9F, -12F, 12F, 3F, 10F),
                PartPose.ZERO);

        // الرأس + الخطم + الأذنان + القرنان
        body.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-5F, -3F, -10F, 10F, 9F, 10F)
                        .texOffs(44, 0).addBox(-3.5F, 2F, -13F, 7F, 5F, 3F)
                        .texOffs(66, 0).addBox(5F, -1F, -2F, 4F, 2F, 1F)
                        .texOffs(78, 0).addBox(-9F, -1F, -2F, 4F, 2F, 1F)
                        .texOffs(0, 20).addBox(5F, -4F, -5F, 6F, 2F, 2F)
                        .texOffs(18, 20).addBox(-11F, -4F, -5F, 6F, 2F, 2F)
                        .texOffs(36, 20).addBox(9F, -11F, -5F, 2F, 8F, 2F)
                        .texOffs(46, 20).addBox(-11F, -11F, -5F, 2F, 8F, 2F),
                PartPose.offset(0F, -3F, -13F));

        body.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(100, 0).addBox(-1F, 0F, 0F, 2F, 9F, 2F),
                PartPose.offsetAndRotation(0F, -5F, 13F, 0.3F, 0F, 0F));

        root.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(0, 100).addBox(-2.5F, 0F, -2.5F, 5F, 9F, 5F),
                PartPose.offset(5.5F, 15F, -9.5F));
        root.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(20, 100).addBox(-2.5F, 0F, -2.5F, 5F, 9F, 5F),
                PartPose.offset(-5.5F, 15F, -9.5F));
        root.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(40, 100).addBox(-2.5F, 0F, -2.5F, 5F, 9F, 5F),
                PartPose.offset(5.5F, 15F, 9.5F));
        root.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(60, 100).addBox(-2.5F, 0F, -2.5F, 5F, 9F, 5F),
                PartPose.offset(-5.5F, 15F, 9.5F));

        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(WaterBuffaloEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float pt = ageInTicks - entity.tickCount;
        float sit = entity.getSitAmount(pt);   // 0 = واقف ، 1 = جالس
        float eat = entity.getEatAnimationScale(pt);

        // الجلوس: ينزل الجسم وتنطوي الأرجل
        body.y = 9F + sit * 6F;
        float legY = 15F + sit * 6F;
        legFL.y = legFR.y = legBL.y = legBR.y = legY;

        // الرأس
        head.xRot = 0.4F + headPitch * Mth.DEG_TO_RAD * (1F - eat)
                + eat * (0.9F + Mth.sin(ageInTicks * 0.9F) * 0.08F);
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD * (1F - 0.7F * eat);

        // المشي
        float swing = limbSwing * 0.6662F;
        float amp = 1.2F * limbSwingAmount * (1F - sit);
        float fold = -1.45F * sit;
        legFL.xRot = Mth.cos(swing) * amp + fold;
        legBR.xRot = Mth.cos(swing) * amp + fold;
        legFR.xRot = Mth.cos(swing + Mth.PI) * amp + fold;
        legBL.xRot = Mth.cos(swing + Mth.PI) * amp + fold;

        tail.xRot = 0.3F + Mth.cos(ageInTicks * 0.2F) * 0.1F + limbSwingAmount * 0.4F;
        tail.zRot = Mth.sin(ageInTicks * 0.15F) * 0.15F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
