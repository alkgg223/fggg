# مود الجاموس – NeoForge 1.21.1 (21.1.264)

## التركيب
1. حمّل MDK الرسمي لـ 1.21.1 من https://github.com/NeoForgeMDKs/MDK-1.21.1-NeoGradle
2. في gradle.properties: minecraft_version=1.21.1 ، neo_version=21.1.264 ، mod_id=waterbuffalo
3. احذف ExampleMod.java و مجلد src/main/templates
4. انسخ مجلد src من هذا المشروع فوق src الخاص بالـ MDK
5. شغّل: gradlew runClient  (أو gradlew build للحصول على ملف jar)

## الإعدادات
- الدم 80 (4 أضعاف اللاعب) ، الضرر 12 (ضربتان تقتلان على الصعوبة العادية)
- يظهر في المستنقعات وأنهار
- الأكل: قمح/بذور/خبز/تبن/جزر/بطاطس/شمندر (من اليد أو الأرض) + المحاصيل الناضجة المزروعة
- العنف فقط عند ضربه
